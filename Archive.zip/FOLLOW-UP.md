# Implementation:

### Q) What libraries did you add to the frontend? What are they used for?
Some backpack components for displaying icons/spinners
Axios to make http requests
moment to handheld timestamps

### Q) What is the command to start the server?

APIKEY=ss630745725358065467897349852985 npm run server 

---

# General:

### Q) How long, in hours, did you spend on the test?
7 hours over the course of a week

### Q) If you had more time, what further improvements or new features would you add?
Validation on input provided by the client
Support legs with multiple segments (non-direct legs)
Fetch more results on scrolling down

### Q) Which parts are you most proud of? And why?
Frontend - because it looks quite nice

### Q) Which parts did you spend the most time with? What did you find most difficult?
Front end and formatting the data to be consumed by the frontend

### Q) How did you find the test overall? If you have any suggestions on how we can improve the test or our API, we'd love to hear them.
The project can't be installed on windows
Dependencies need to be updated, I had to update to latest react version to use hooks
API documentation could be clearer, in particular some documentation on the Legs and Segements arrays in the response