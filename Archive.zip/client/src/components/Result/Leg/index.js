import Leg from './Leg';

export default Leg;
